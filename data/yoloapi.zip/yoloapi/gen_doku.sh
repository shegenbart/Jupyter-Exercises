pdoc --html --force -c latex_math=True .
